## Background

This problem is an exercise on prefix sums. **Please solve this problem using prefix sums.**

Please use C++, and use `scanf()` instead of `std::cin`.

## Description

Given an integer sequence, find the sum from the $l$-th term to the $r$-th term.

## Input

The input consists of $3$ lines:  
- Line 1: A positive integer $n$, the length of the integer sequence.  
- Line 2: $n$ integers $a_1, a_2, \cdots, a_n$, representing the integer sequence.  
- Line 3: Two positive integers $l$ and $r$, indicating that we require the sum from the $l$-th to the $r$-th term.

## Output

Output one line with a single integer $s$, the sum from the $l$-th to the $r$-th term in the integer sequence.

```input1
6
178 24 16 -19 52 1
2 4
```

```output1
21
```

## Hint

For test cases #1 to #10, it is guaranteed that $1 \le n \le 6000$, $-10^5 \le a_i \le 10^5$, and $1 \le l \le r \le n$.

For test case #11, $n = 10^6$ and $-10^5 \le a_i \le 10^5$.