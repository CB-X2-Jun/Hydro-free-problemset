## Description

Given the preorder and inorder traversal sequences of a binary tree, output its postorder traversal.

## Input

The input consists of two lines.

Line $1$: The preorder traversal of the binary tree.

Line $2$: The inorder traversal of the binary tree.

## Output

Output one line containing the postorder traversal of the binary tree.

```input1
ABCD
CBAD
```

```output1
CBDA
```

## Hint

For $100\%$ of the test cases, the input string length $1 \le$ is $\le 20$, containing only uppercase letters.

The data guarantees a valid solution.

【Sample #1 Explanation】

The binary tree structure is as follows:
```plain
      A
     / \
    B   D
   /
  C
```