## Description

In the ruins, traces of war remain, along with scattered remnants of walls and towers. These structures were once connected, but the war has fragmented them.

To restore them, we first need to determine how many sections the walls are divided into. Here, walls and towers are considered as one entity. Given a map, your task is to calculate how many separate sections the wall is divided into.

## Input

Line $1$: Two positive integers $n,m$, indicating the map has $n$ rows and $m$ columns.

Line $2 \sim n+1$: Input a $n$-row by $m$-column map consisting only of the characters `#` and `.`. `#` represents walls or towers, while `.` represents empty space.

Structures shaped like the following are considered a single connected section:
```plain
#.
.#
```

## Output

Output a natural number $s$, representing the number of sections the wall is divided into.

```input1
4 5
#...#
##..#
...#.
#....
```

```output1
3
```

## Hint

For $100\%$ of the data, $2 \le n,m \le 50$.

【Sample #1 Explanation】

The map contains three sections:
1. Top-left section:  
```plain
#.
##
```
2. Top-right section:
```plain
.#
.#
#.
```
3. Bottom-left section:
```plain
#
```