## Background
Little A loves the letter `A`. He wants to know how many times the letter `A` appears in a message sent by his friend (counting both uppercase and lowercase).

## Description
Write a program that inputs a string $s$ containing spaces and outputs the number of times the letter `A` appears (counting both uppercase and lowercase).

## Input
A single line containing the string $s$ with spaces.

## Output
Output the count of the letter `A` (case-insensitive) in the string $s$.

```input1
How are you today?
```
```output1
2
```

```input2
Hello, Little A! The weather's great, let's go to the park and play badminton.
```
```output2
7
```
## Constraints
For $20\%$ of the data, the string $s$ contains only lowercase letters.

For $100\%$ of the data, $|s| \leq 100$ (the length of $s$ is at most $100$).