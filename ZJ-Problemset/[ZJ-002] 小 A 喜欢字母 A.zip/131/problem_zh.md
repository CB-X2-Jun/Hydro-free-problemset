## 题目背景

小A喜欢字母 `A`。他想知道朋友发过来的消息中有多少个字母 `A`（大小写都算）。

## 题目描述

请你编程输入一个**含有空格的**字符串 $s$，输出其中字母 `A` 的个数（大小写都算）。

## 输入格式

输入仅一行，带空格的字符串 $s$。

## 输出格式

输出字符串 $s$ 中字母 `A` 的个数（大小写都算）。

```input1
How are you today?
```

```output1
2
```

```input2
Hello, Little A! The weather's great, let's go to the park and play badminton.
```

```output2
7
```

## 提示

### 【数据规模与约定】
对于 $20\%$ 的数据，字符串 $s$ 仅含有小写字母。  
对于 $100\%$ 的数据，$|s| \leq 100$。