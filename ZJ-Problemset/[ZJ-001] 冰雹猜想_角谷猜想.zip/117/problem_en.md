## Background

### The Collatz Conjecture states that:
For any positive integer $x$:
- If it's odd, multiply it by $3$ and add $1$, i.e.: $x \rarr x \times 3 + 1$;

- If it's even, divide it by $2$, i.e.: $x \rarr \dfrac{x}{2}$.

By repeating these operations, the number will eventually reach $1$ and fall into the $1 \rarr 4 \rarr 2 \rarr 1 \rarr 4 \rarr \cdots$ loop.

## Description

Now, write a program to calculate how many operations are needed for a positive integer $x$ to transform into $1$.

## Input

A single line containing the positive integer $x$ to be processed.

## Output

A non-negative integer $s$, representing the number of operations required.

```input1
7
```

```output1
16
```

```input2
8
```

```output2
3
```

## Hint

### 【Data Scale and Convention】
For $100\%$ of the data, $1 \leq x \leq 2 \times 10^6$.